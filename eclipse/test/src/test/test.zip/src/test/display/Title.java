package test.display;



public class Title {
		public static final String TITLE = "　　　　　　　　　　　　　　　　　　　　　　카페 관리 프로그램 " ;	
}
